"""Adjudicate only recorded procedure candidates before graph replay."""
from concurrent.futures import ThreadPoolExecutor
from audit import HERE,read,rows,candidates,failure_packet,model_review

def review(r):
    q=r['question_id']
    b=HERE/'source/B4'/r['dataset']
    p=read(next((b/'predictions').glob('*/'+q+'.json')))
    offered,events=candidates(read(b/'evidence'/f'{q}.json'),p,read(b/'steps'/f'{q}.json'),False)
    result=model_review(failure_packet(offered,events),HERE/'model_reviews'/f'{q}.json')
    return q,result['accepted']

if __name__=='__main__':
    selected=[r for r in rows(HERE/'audit/writes.jsonl') if not r['correct'] and r['new_procedure_candidates']]
    print(*review(selected[0]),flush=True)
    with ThreadPoolExecutor(4) as pool:
        for q,result in pool.map(review,selected[1:]):
            print(q,result,flush=True)
