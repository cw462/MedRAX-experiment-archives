"""Post-feedback strategy review using only enumerated, receipt-backed observations."""
import json
import copy
import re
from pathlib import Path
from r56.memory import STRATEGIES
from r56.policy import task_profile

NEW = {
    'frontal_tool_on_ineligible_view': ('Check frontal-only tool eligibility against the recorded view before requesting localization or a grounded report.', 'failure'),
    'alternative_after_ineligible_tool': ('After a tool declines the recorded view, use a view-compatible observation from the same image if further evidence is needed.', 'success')
}
FRONTAL = {'xray_phrase_grounding', 'maira2_grounded_report'}

def scoped_retrieve(graph,task,ordinal):
    # View-eligibility procedures apply across findings. Localization lessons
    # require a known matching finding on the same task and view.
    subset=copy.copy(graph)
    subset.nodes={n.id:n for n in graph.nodes.values()
                  if n.task==task.kind and n.view==task.view and n.view!='unknown' and
                  (n.mechanism in NEW or (n.finding==task.finding and n.finding!='unknown'))}
    result=subset.retrieve(task,ordinal=ordinal,gated=False)
    result['out_of_scope_ids']=sorted(set(graph.nodes)-set(subset.nodes))
    return result

def tool_events(prediction, steps):
    turns = []
    for step in steps:
        try:
            action = json.loads(step['response'].strip().removeprefix('''```json''').removesuffix('''```''').strip())
        except (ValueError, TypeError):
            continue
        if isinstance(action, dict):
            turns.extend((step['step_index']+1, a.get('tool')) for a in action.get('calls',[]) if isinstance(a,dict))
    observations = prediction['observations']
    exact = [name for _,name in turns] == [r['tool'] for r in observations]
    events = []
    for i,r in enumerate(observations,1):
        payload = r['observation']
        meta = payload[-1] if isinstance(payload,list) and payload and isinstance(payload[-1],dict) else payload
        meta = meta if isinstance(meta,dict) else {}
        status = meta.get('analysis_status') if r['status']=='completed' else r['status']
        view = meta.get('view_record',{}).get('view')
        args = r.get('identity',{}).get('args',{})
        events.append({'ordinal':i,'turn':turns[i-1][0] if exact else None,'tool':r['tool'],
                       'image_index':r.get('image_index',1),'analysis_status':status,'view':view,
                       'nonfrontal_decline':status=='not_applicable' and view=='lateral' and r['tool'] in FRONTAL,
                       'args':args})
    return events

def candidates(evidence, prediction, steps, correct):
    from r56.memory import derive_mechanisms
    events = tool_events(prediction,steps)
    tags = derive_mechanisms(correct=correct, signals=dict.fromkeys(evidence['signals'],True))
    out = {t:evidence['signals'][t] for t in tags}
    blocked = [e for e in events if e['nonfrontal_decline']]
    if blocked and not correct:
        out['frontal_tool_on_ineligible_view'] = [e['ordinal'] for e in blocked]
    if correct:
        for b in blocked:
            recovery = next((e for e in events if e['image_index']==b['image_index']
                             and e['turn'] and b['turn'] and e['turn']>b['turn']
                             and e['analysis_status']=='completed' and e['tool'] not in FRONTAL),None)
            if recovery:
                out['alternative_after_ineligible_tool'] = [b['ordinal'],recovery['ordinal']]
                break
    return out, events

HYPOTHESES = {
    'frontal_tool_on_ineligible_view':'A tool was requested for a view outside its supported views.',
    'opposing_candidate_boxes':'Localization produced regions for two opposing directional prompts.',
    'format_answer_changed':'Formatting the answer changed the previously selected choice.',
    'roi_invalid_coordinates':'The requested region had invalid coordinates.',
    'orientation_conflict':'The stated patient-side mapping contradicted verified orientation.',
    'explicit_tool_conflict':'Independent tools reported opposite sides for the same finding.'
}

def failure_packet(tags, events):
    facts=[]
    for e in events:
        obs={k:e[k] for k in ('ordinal','turn','tool','analysis_status','view','nonfrontal_decline')}
        if e['tool']=='xray_phrase_grounding':
            obs['directional_query']=bool(re.search(r'\b(left|right)\b',e['args'].get('phrase',''),re.I))
        facts.append(obs)
    return {'candidates':sorted(tags),'observations':facts,'witnesses':tags}

def witness_text(tag, packet):
    refs=packet['witnesses'][tag]
    chosen=[e for e in packet['observations'] if isinstance(refs,list) and e['ordinal'] in refs]
    if tag=='frontal_tool_on_ineligible_view':
        return ' '.join(f"Call {e['ordinal']} requested {e['tool']} on a lateral radiograph. The service returned not applicable because it requires a frontal radiograph." for e in chosen if e['nonfrontal_decline'])
    if tag=='opposing_candidate_boxes':
        return ('Two different calls on the same image returned boxes, one for each of two opposite directional queries.'
                if sum(e.get('directional_query',False) for e in chosen)>=2 else '')
    if tag=='format_answer_changed' and 'completion_turn' in refs:
        return 'Before and after the format repair request, the two explicit selections were different.'
    if tag=='orientation_conflict' and refs['verified_patient_side']!=refs['claimed_patient_side']:
        return 'The conclusion used the opposite mapping to the image orientation verified in metadata.'
    if tag=='roi_invalid_coordinates' and refs:
        return 'A tool receipt recorded an invalid box or a rejected original coordinate mapping.'
    if tag=='explicit_tool_conflict' and len({e['tool'] for e in chosen})>=2:
        return 'Two different tools on the same image explicitly reported opposite sides for the queried finding.'
    return ''

from functools import lru_cache
import sys
import numpy as np

@lru_cache(maxsize=1)
def nli():
    folder=Path(__file__).resolve().parent
    sys.path.insert(0,str(folder/'nli_deps'))
    import onnxruntime as ort
    from tokenizers import Tokenizer
    model=folder/'local_nli'
    # On the GPU host the same pinned files can be mounted at this path.
    tok=Tokenizer.from_file(str(model/'tokenizer.json'))
    opts=ort.SessionOptions()
    opts.intra_op_num_threads=2
    session=ort.InferenceSession(str(model/'model.onnx'),opts,providers=['CPUExecutionProvider'])
    labels=json.loads((model/'config.json').read_bytes())['id2label']
    return tok,session,labels,(model/'revision.txt').read_text().strip()

def model_review(packet, path):
    if path.exists():
        receipt=json.loads(path.read_bytes())
        if packet!=receipt['input']:raise ValueError('attribution receipt does not match this trace')
        return receipt
    tok, session, labels, revision=nli()
    accepted=[];decisions=[]
    for tag in packet['candidates']:
        premise=witness_text(tag,packet)
        if not premise:
            decisions.append({'candidate':tag,'decision':'insufficient_trace'})
            continue
        hypothesis=HYPOTHESES[tag]
        seq=tok.encode(premise,hypothesis)
        tensors={'input_ids':seq.ids,'attention_mask':seq.attention_mask,'token_type_ids':seq.type_ids}
        inp={i.name:np.asarray([tensors[i.name]],dtype=np.int64) for i in session.get_inputs()}
        logits=session.run(None,inp)[0][0]
        decision=labels[str(int(logits.argmax()))].lower()
        if decision=='entailment':accepted.append(tag)
        decisions.append({'candidate':tag,'premise':premise,'hypothesis':hypothesis,'decision':decision,
                          'logits':{labels[str(i)]:float(x) for i,x in enumerate(logits)}})
    result={'input':packet,'accepted':sorted(accepted),'model':'Xenova/mobilebert-uncased-mnli',
            'revision':revision,'decisions':decisions}
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(result,indent=2));temp.replace(path)
    return result
