"""B4-Fix native memory integration; legacy B1/B4 keep their original entry point."""
import hashlib
import json

def fixed_configure(legacy, arm, service_class, memory_class, manifest, out, data):
    if arm != 'B4-Fix':
        return legacy(arm,service_class,memory_class,manifest,out,data)
    from evo_hooks import aligned_verdict,read,save_once,orientations
    from r56.policy import Task,task_profile
    from r56.memory import STRATEGIES
    from strategy_fix import NEW,candidates,model_review,failure_packet,scoped_retrieve
    STRATEGIES.update(NEW)
    services,tools,legacy_graph=legacy('B4',service_class,memory_class,manifest,out,data)
    manifest['evo_policy']['post_feedback_attribution']='local_mobilebert_mnli'
    views=orientations(manifest,data)
    class FixedMemory(legacy_graph):
        def retrieve(self,row):
            q=row['question_id']
            cfm=memory_class.retrieve(self,row)
            vv={views[str((data/image).resolve())].view for image in row['images']}
            task=task_profile(row['question'],row.get('options',{}),next(iter(vv)) if len(vv)==1 else 'unknown')
            rec=scoped_retrieve(self.graph,task,self.ordinals[q])
            rec.update(created_ordinals={k:self.graph.nodes[k].created_ordinal for k in rec['injected_ids']},
                       injected_chars=sum(map(len,rec['notes'])),actual_adopted_ids=None)
            save_once(out/'strategy/retrieval'/f'{q}.json',rec)
            return '\n\n'.join(x for x in (cfm,'\n'.join(rec['notes'])) if x)

        def ingest(self,row,trace,feedback):
            memory_class.ingest(self,row,trace,feedback)
            q=row['question_id'];idx=self.ordinals[q]
            receipt=out/'strategy/writes'/f'{q}.json'
            if receipt.exists():
                return
            prediction_path=out/'predictions'/manifest['arm']/f'{q}.json'
            raw=prediction_path.read_bytes();pred=json.loads(raw)
            if (pred!=trace['prediction'] or pred!=feedback['saved_prediction']
                    or feedback['timing']!='after_immutable_prediction'):
                raise ValueError('Unbound post-prediction feedback')
            correct=aligned_verdict(row,pred,feedback['reference_annotation'])
            evidence=read(out/'evidence'/f'{q}.json')
            proposed,events=candidates(evidence,pred,read(out/'steps'/f'{q}.json'),correct)
            approved=list(proposed)
            if proposed and not correct:
                approval=model_review(failure_packet(proposed,events),out/'attribution'/f'{q}.json')
                approved=approval['accepted']
            task=Task(**evidence['task'])
            if idx==self.graph.last_ordinal:
                written=[n.id for n in self.graph.nodes.values() if n.last_ordinal==idx]
                result={'written_ids':written,'nodes':len(self.graph.nodes),'edges':len(self.graph._edges())}
            else:
                result=self.graph.update(task=task, correct=correct,verified_mechanisms=approved,ordinal=idx,
                    frozen_prediction=prediction_path,prediction_sha256=hashlib.sha256(raw).hexdigest(),feedback_released=True)
            save_once(receipt,dict(result,verdict=correct,candidates=proposed,accepted=approved,
                                   rejected=sorted(set(proposed)-set(approved)),sources={k:proposed[k] for k in approved},
                                   skipped_reason=None if approved else ('model_abstained' if proposed else 'no_trace_witness')))
    return services,tools,FixedMemory
