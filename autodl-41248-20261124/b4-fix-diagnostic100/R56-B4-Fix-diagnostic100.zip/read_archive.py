"""Read the formal paired archive without unpacking duplicate model/image caches."""
import argparse
import json
import tarfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

def extract(archive, target):
    with tarfile.open(archive, 'r|gz') as package:
        for member in package:
            parts = member.name.strip('/').split('/')
            if not member.isfile() or '..' in parts or len(parts) < 2:
                continue
            if parts[1] != 'runs':
                continue
            path = parts[3:]
            if not path or path[0] not in ('B1','B4'):
                continue
            if len(path) == 2:
                keep = path[1] == 'scores.jsonl'
            elif len(path) >= 3:
                keep = path[2] in ('manifest.json','predictions','evidence','strategy','steps','feedback','contexts')
                if path[2:5] == ['services','calls','R49-AGENT'] and path[-1]=='request.json':
                    keep = True
                if path[2:5] == ['services','tool_selections','R49-AGENT']:
                    keep = True
            else:
                keep = False
            if keep:
                dest = target.joinpath(*path)
                dest.parent.mkdir(parents=True,exist_ok=True)
                dest.write_bytes(package.extractfile(member).read())

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('archive',type=Path)
    p.add_argument('target',type=Path)
    a = p.parse_args()
    extract(a.archive,a.target)
