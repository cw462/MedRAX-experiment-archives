"""Reconstruct historical gates, compare tool use and replay sidecar updates before the next case."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import shutil
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'R56_M5_Evo'))
from r56.memory import StrategyGraph,STRATEGIES
from r56.policy import Task,task_profile
from strategy_fix import NEW,candidates,model_review,failure_packet,tool_events,scoped_retrieve
import re

def read(p):
    return json.loads(p.read_bytes())

def rows(p):
    return [json.loads(l) for l in p.read_text().splitlines()]

def dump(p,values):
    p.write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in values),encoding='utf-8')

def target_behavior(task,events):
    target=task['finding']
    neutral = []
    for e in events:
        phrase=e['args'].get('phrase','')
        if (e['tool']=='xray_phrase_grounding' and e['analysis_status']=='completed' and
            target!='unknown' and task_profile(phrase,{}).finding==target and
            not re.search(r'\b(left|right)\b',phrase,re.I)):
            neutral.append(e['ordinal'])
    return {'completed_neutral_target_grounding':neutral,'completed_roi':[
        e['ordinal'] for e in events if e['tool']=='roi_crop' and e['analysis_status']=='completed']}

def main(fix):
    src=HERE/'source'
    dest=HERE/('fixed_replay' if fix else 'audit')
    dest.mkdir(exist_ok=True)
    s1={r['question_id']:r for r in rows(src/'B1/scores.jsonl')}
    data=rows(src/'B4/scores.jsonl')
    audit=[]; injections=[]; pairs=[]; allobs=[]; deltas=[]; snapshots={}
    historical_tags=set(STRATEGIES)
    scratch=tempfile.TemporaryDirectory()
    if fix: STRATEGIES.update(NEW)
    for index,score in enumerate(data,1):
        q,ds=score['question_id'],score['dataset']
        a,b=(src/arm/ds for arm in ('B1','B4'))
        ap=next((a/'predictions').glob('*/'+q+'.json'));bp=next((b/'predictions').glob('*/'+q+'.json'))
        pred=read(bp); base=read(ap); e=read(b/'evidence'/f'{q}.json')
        f=read(b/'feedback'/f'{q}.json')
        w=read(b/'strategy/writes'/f'{q}.json')
        rr=read(b/'strategy/retrieval'/f'{q}.json')
        steps=read(b/'steps'/f'{q}.json')
        correct=score['correct'];task=e['task']
        assert w['verdict']==correct and f['saved_prediction']==pred and f['timing']=='after_immutable_prediction'
        offered,events=candidates(e,pred,steps,correct)
        baseline=tool_events(base,read(a/'steps'/f'{q}.json'))
        for arm,pr,evs in [('B1',base,baseline),('B4',pred,events)]:
            for ev,obs in zip(evs,pr['observations'],strict=True):
                allobs.append(dict(question_id=q,dataset=ds,arm=arm,event=ev,receipt=obs))
        pairs.append({'question_id':q,'dataset':ds,'B1_answer':base['answer'],'B4_answer':pred['answer'],
                      'B1_correct':s1[q]['correct'],'B4_correct':correct})
        tools=e['tools'];signals=e['signals']
        reasons={
            'verified_bilateral_comparison':'no_runtime_extractor',
            'verified_device_trace':'no_runtime_extractor',
            'verified_complementary_evidence':('not_laterality' if task['kind']!='laterality' else
                'no_two_distinct_tools_with_explicit_same_image_side' if len({t['tool'] for t in tools
                if t['kind'] in ('report','expert') and t['side'] in ('left','right')})<2 else 'terminal_side_not_established'),
            'orientation_conflict':('unverified_original_orientation' if not any(v['confirmed'] for v in e['original_views'])
                                      else 'no_explicit_contradiction_observed'),
            'opposing_candidate_boxes':'no_same_finding_opposing_box_pair',
            'format_answer_changed':'no_verified_format_only_selection_change',
            'roi_invalid_coordinates':'no_recorded_invalid_coordinates',
            'explicit_tool_conflict':'no_two_distinct_tools_with_opposing_finding_sides'}
        review=[]
        for k in sorted(historical_tags):
            polarity=STRATEGIES[k][1]
            gate=(polarity=='success')==correct
            review.append({'mechanism':k,'candidate':k in signals,'evidence':signals.get(k),
                           'outcome_eligible':gate,'decision':'accepted' if k in w['sources'] else
                           'rejected' if k in signals else 'not_generated',
                           'reason':'matched_trace_and_verdict' if k in w['sources'] else
                           'wrong_outcome_polarity' if k in signals and not gate else reasons[k]})
        changed=[{'old':old['kind'],'actual':'not_applicable','tool':x['tool'],'ordinal':x['ordinal']}
                 for x,old in zip(events,tools,strict=True) if x['analysis_status']=='not_applicable']
        previous=snapshots.get(ds,set())
        audit.append({'ordinal':index,'dataset_ordinal':pred['ordinal'],'dataset':ds,'question_id':q,
                      'correct':correct,'task':task,'signals':signals,'template_review':review,
                      'write_receipt':w,'created':sorted(set(w['written_ids'])-previous),
                      'deduplicated':sorted(set(w['written_ids'])&previous),'field_mismatches':changed,
                      'new_procedure_candidates':offered})
        snapshots[ds]=previous|set(w['written_ids'])
        if rr['injected_ids']:
            g=read(b/'strategy/graph.json');nodes={n['id']:n for n in g['nodes']}
            req=read(b/'services/calls/R49-AGENT'/q/'1/request.json')
            for nid,note in zip(rr['injected_ids'],rr['notes'],strict=True):
                assert note in json.dumps(req['messages'])
                n=nodes[nid];b1_seq=[v['tool'] for v in baseline];b4_seq=[v['tool'] for v in events]
                a_beh=target_behavior(task,baseline);b_beh=target_behavior(task,events)
                injections.append(dict(question_id=q,source_node=nid,task=task,ordinal=index,
                    source_task=n['task'],source_finding=n['finding'],source_view=n['view'],
                    task_match=n['task']==task['kind'],finding_match=n['finding']==task['finding'],
                    view_match=n['view']==task['view'],B1_tools=b1_seq,B4_tools=b4_seq,sequence_changed=b1_seq!=b4_seq,
                    calls_or_args_changed=[(x['tool'],x['args'],x['image_index']) for x in baseline]!=
                        [(x['tool'],x['args'],x['image_index']) for x in events],B1_behavior=a_beh,B4_behavior=b_beh,
                    B1_correct=s1[q]['correct'],B4_correct=correct,in_first_prompt=True))
        if fix:
            gdir=Path(scratch.name)/ds
            if pred['ordinal']==1:
                # Replay from an empty graph; all historical archives remain read-only.
                graph=StrategyGraph(gdir/'graph.json')
                if graph.last_ordinal: raise ValueError('Use a fresh output directory for graph replay')
            task_obj=Task(**task)
            broad=graph.retrieve(task_obj,ordinal=pred['ordinal'],gated=False)
            before=scoped_retrieve(graph,task_obj,pred['ordinal'])
            chosen=list(offered)
            if not correct and offered:
                receipt=model_review(failure_packet(offered,events),HERE/'model_reviews'/f'{q}.json')
                chosen=receipt['accepted']
            prior_ids=set(graph.nodes)
            applied=graph.update(task=task_obj, correct=correct, verified_mechanisms=chosen,
                    ordinal=pred['ordinal'],frozen_prediction=bp,prediction_sha256=hashlib.sha256(bp.read_bytes()).hexdigest(),
                    feedback_released=True)
            deltas.append(dict(question_id=q,dataset=ds,ordinal=pred['ordinal'],original_injections=rr['injected_ids'],
                               replay_retrieval=before,write_only_retrieval=broad,original_write=w,
                               proposed=offered,accepted=chosen,update=applied,
                               created=sorted(set(applied['written_ids'])-prior_ids),
                               merged=sorted(set(applied['written_ids'])&prior_ids)))
    dump(dest/'writes.jsonl',audit);dump(dest/'injections.jsonl',injections)
    dump(dest/'paired_scores.jsonl',pairs);dump(dest/'tool_trajectories.jsonl',allobs)
    if fix:
        dump(dest/'graph_deltas.jsonl',deltas)
        shutil.copytree(scratch.name,dest/'graphs',dirs_exist_ok=True)
    scratch.cleanup()
    print(len(audit),len(injections),len(allobs),collections.Counter((r['correct'],bool(r['new_procedure_candidates'])) for r in audit))
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--fix',action='store_true')
    main(p.parse_args().fix)
