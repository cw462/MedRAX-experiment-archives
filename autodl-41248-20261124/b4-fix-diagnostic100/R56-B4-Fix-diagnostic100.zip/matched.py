"""Hold same-image memory and CFM text to the exact archived B4 pre-question state."""
import argparse
import json
from unittest.mock import patch
from run_groups import HERE,load,native,submanifest

def run(label):
    import evo_hooks
    import run_online_skill_r54 as engine
    from online_memory_r49 import save_once
    if label not in ('matched_B1_a','matched_B1_b','matched_B4','matched_fix'):
        raise ValueError(label)
    src=HERE.parent/'R56_M5_Evo_B4_validation/runs/diagnostic100/B4'
    changes={r['question_id']:r for r in map(json.loads,(HERE/'fixed_replay/graph_deltas.jsonl').read_text().splitlines())}
    legacy=evo_hooks.configure
    scope='matched/'+label
    results=[]
    with patch.object(native,'HERE',HERE),native.arm_lease(scope,'B1'):
        for ds in native.DATASETS:
            old=src/ds
            ids=[r['question_id'] for r in load(old/'manifest.json')['order']]
            def context(prior,item,ordinal):
                obj=load(old/'contexts'/f"{item['question_id']}.json")
                if obj['ordinal']!=ordinal:raise ValueError('context order mismatch')
                return obj['same_image_context'],obj['same_image_ids']

            def configure(arm, services, mem, manifest, out, data):
                svc,tools,_=legacy('B1',services,mem,manifest,out,data)
                class FrozenMemory:
                    def __init__(self,*args,**kwargs):pass
                    def retrieve(self,row):
                        q=row['question_id']
                        cfm=load(old/'external_memory/episodes'/q/'retrieval.json')['injected']
                        original=load(old/'strategy/retrieval'/f'{q}.json')
                        if label=='matched_B4':
                            notes=original
                        elif label=='matched_fix':
                            notes=changes[q]['replay_retrieval']
                        else:
                            notes={'notes':[],'injected_ids':[]}
                        save_once(out/'frozen_retrieval'/f'{q}.json',{'cfm':cfm,'strategy':notes,'source':'historical_B4'})
                        return '\n\n'.join(x for x in (cfm,'\n'.join(notes['notes'])) if x)
                    def ingest(self,row,trace,feedback):
                        if feedback['timing']!='after_immutable_prediction' or feedback['saved_prediction']!=trace['prediction']:
                            raise ValueError('Unbound feedback')
                return svc,tools,FrozenMemory
            m=submanifest(ds,ids)
            m['matched_history']=label
            with patch.object(engine,'context',context),patch.object(evo_hooks,'configure',configure):
                native.run(scope,'B1',ds,m)
            official=load(HERE/'runs'/scope/'B1'/ds/'analysis/per_question.json')
            if [r['question_id'] for r in official]!=ids:raise ValueError('matched score order')
            results.extend(dict(dataset=ds,**{k:r[k] for k in ('question_id','correct','main_calls','tool_calls')}) for r in official)
    if len(results)!=100:raise ValueError('incomplete matched panel')
    out=HERE/'runs'/scope/'paired_scores.jsonl'
    tmp=out.with_suffix('.tmp');tmp.write_text(''.join(json.dumps(r)+'\n' for r in results));tmp.replace(out)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('arm',choices=['matched_B1_a','matched_B1_b','matched_B4','matched_fix'])
    run(p.parse_args().arm)
