import copy
import unittest
from audit import HERE,read,rows,tool_events,candidates,scoped_retrieve,StrategyGraph,Task
from strategy_fix import failure_packet,model_review,nli

class Receipts(unittest.TestCase):
    def test_blocked_view_is_distinct_from_negative_grounding(self):
        traces=rows(HERE/'audit/tool_trajectories.jsonl')
        negative=[r for r in traces if r['arm']=='B4' and r['event']['analysis_status']=='completed_no_finding']
        self.assertEqual(4,len(negative))
        self.assertFalse(any(r['event']['nonfrontal_decline'] for r in negative))
    def test_success_needs_a_later_decision(self):
        row=next(r for r in rows(HERE/'audit/writes.jsonl') if 'alternative_after_ineligible_tool' in r['new_procedure_candidates'])
        ds,q=row['dataset'],row['question_id'];p=HERE/'source/B4'/ds
        evidence=read(p/'evidence'/f'{q}.json');pred=read(next((p/'predictions').glob('*/'+q+'.json')))
        steps=read(p/'steps'/f'{q}.json')
        self.assertIn('alternative_after_ineligible_tool',candidates(evidence,pred,steps,True)[0])
        self.assertNotIn('alternative_after_ineligible_tool',candidates(evidence,pred,[],True)[0])
    def test_old_node_scope_preserves_matched_recall(self):
        q='chexbench_openi_0194';p=HERE/'source/B4/chexbench'
        graph=StrategyGraph(p/'strategy/graph.json')
        task=read(p/'evidence'/f'{q}.json')['task']
        matched=scoped_retrieve(graph,Task(**task),93)
        self.assertEqual(1,len(matched['injected_ids']))
        self.assertFalse(scoped_retrieve(graph,Task(**dict(task,view='lateral')),93)['injected_ids'])
    def test_local_reviewer_matches_archived_grounding_verdict(self):
        import tempfile
        old=read(HERE/'model_reviews/chexbench_openi_0194.json')
        with tempfile.TemporaryDirectory() as tmp:
            from pathlib import Path
            fresh=model_review(old['input'],Path(tmp)/'receipt.json')
        self.assertEqual(old['accepted'],fresh['accepted'])
        self.assertEqual(fresh['accepted'],['opposing_candidate_boxes'])

if __name__=='__main__':unittest.main()
