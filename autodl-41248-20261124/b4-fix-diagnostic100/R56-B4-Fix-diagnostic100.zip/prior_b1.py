"""Stream the original S2 archive until the archived B1 scoring table is found."""
import concurrent.futures
import io
import json
import tarfile
import urllib.request
from pathlib import Path
URL='https://media.githubusercontent.com/media/cw462/MedRAX-experiment-archives/autodl-10233-20261124/autodl-41248-20261124/r56-evo-s2-tools-41248.tar.gz'
def part(lo,hi):
    for i in range(3):
        try:
            req=urllib.request.Request(URL+'?b1audit='+str(lo),headers={'Range':f'bytes={lo}-{hi}'})
            with urllib.request.urlopen(req, timeout=75) as r:
                if not r.headers.get('Content-Range','').startswith(f'bytes {lo}-{hi}/'):
                    raise ValueError('wrong archive range')
                buf=r.read()
                if len(buf)!=hi-lo+1:raise ValueError('short response')
                return buf
        except Exception:
            if i==2: raise

class Parts(io.RawIOBase):
    def __init__(self,pool,size):
        self.pool=pool
        self.ranges=iter((a,min(size-1,a+2**21-1)) for a in range(0,size,2**21))
        self.queue=[];self.buf=b''
        for _ in range(10):self.schedule()
    def schedule(self):
        pair=next(self.ranges,None)
        if pair:self.queue.append(self.pool.submit(part,*pair))
    def read(self,n):
        if not self.buf and self.queue:
            self.buf=self.queue.pop(0).result();self.schedule()
        b,self.buf=self.buf[:n],self.buf[n:]
        return b

if __name__=='__main__':
    with urllib.request.urlopen(urllib.request.Request(URL+'?b1len=1',headers={'Range':'bytes=0-0'}),timeout=30) as r:
        size=int(r.headers['Content-Range'].split('/')[-1])
    with concurrent.futures.ThreadPoolExecutor(10) as pool:
        stream=Parts(pool,size)
        with tarfile.open(fileobj=stream,mode='r|gz') as t:
            for m in t:
                if m.name.endswith('/B1/scores.jsonl'):
                    target=Path(__file__).resolve().parent/'s2_B1_scores.jsonl'
                    data=t.extractfile(m).read()
                    assert len(data.splitlines())==100
                    target.write_bytes(data);print(m.name,flush=True);break
            else:raise ValueError('no B1 scores')
        for f in stream.queue:f.cancel()
