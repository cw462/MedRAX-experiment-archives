import concurrent.futures
import json
from pathlib import Path
import urllib.request
MODEL='Xenova/mobilebert-uncased-mnli'

def download(folder):
    folder.mkdir(exist_ok=True)
    rev=(folder/'revision.txt').read_text().strip()
    base=f'https://huggingface.co/{MODEL}/resolve/{rev}/'
    def chunk(start,end):
        for attempt in range(4):
            try:
                req=urllib.request.Request(base+f'onnx/model_quantized.onnx?block={start}-{end}',headers={'Range':f'bytes={start}-{end}'})
                with urllib.request.urlopen(req,timeout=90) as r:
                    returned=r.headers['Content-Range']
                    if not returned.startswith(f'bytes {start}-{end}/'):raise ValueError('Unexpected weight segment')
                    data=r.read()
                    if len(data)!=end-start+1:raise ValueError('Incomplete weight segment')
                    return data,int(returned.split('/')[-1])
            except Exception:
                if attempt==3:raise
    size=chunk(0,0)[1]
    out=folder/'model.onnx'
    if out.exists() and out.stat().st_size==size:return
    tmp=folder/'weights.tmp'
    with concurrent.futures.ThreadPoolExecutor(10) as pool,tmp.open('wb') as f:
        for data,_ in pool.map(lambda a:chunk(a,min(a+1048575,size-1)),range(0,size,1048576)):f.write(data)
    tmp.replace(out)
if __name__=='__main__':download(Path(__file__).resolve().parent/'local_nli')
