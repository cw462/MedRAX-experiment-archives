"""Launch one independent native group. The experiment exposes only the two bounded panels."""
import argparse
from contextlib import contextmanager
import copy
import json
from pathlib import Path
import sys
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
LEGACY=HERE.parent/'R56_M5_Evo'
sys.path.insert(0,str(LEGACY))
import run_evo as native
from live_fix import fixed_configure

def load(p):
    return json.loads(p.read_bytes())

def submanifest(dataset, ids):
    m=load(native.HISTORY/dataset/'manifest.json')
    allowed=set(ids)
    for k in ('inputs','order'):
        m[k]=[r for r in m[k] if r['question_id'] in allowed]
        if [r['question_id'] for r in m[k]]!=ids:raise ValueError('frozen_order_mismatch')
    for entry in m['order']:
        entry['previous_ids']=[i for i in entry['previous_ids'] if i in allowed]
    m['reference_files']={q:m['reference_files'][q] for q in ids}
    return m

def run(group):
    import evo_hooks
    src=HERE.parent/'R56_M5_Evo_B4_validation'
    legacy=evo_hooks.configure
    if group in ('fresh_B1_a','fresh_B1_b'):
        arm='B1'
        panel=LEGACY/'panels/diagnostic100.jsonl'
    else:
        arm='B4-Fix' if group=='sequential_fix' else 'B1'
        panel=HERE/'sequential32.jsonl'
        # Each matched replay arm must have finished the native scoring pass.
        for g in ('matched_B1_a','matched_B1_b','matched_B4','matched_fix'):
            if not (HERE/'runs'/'matched'/g/'paired_scores.jsonl').exists():
                raise ValueError('paired same-history study must finish first')
    records=[json.loads(l) for l in panel.read_text().splitlines()]
    with patch.object(native,'HERE',HERE),native.arm_lease(group,arm):
        for ds in native.DATASETS:
            ids=[r['question_id'] for r in records if r['dataset']==ds]
            if not ids:continue
            m=submanifest(ds,ids)
            with patch.object(evo_hooks,'configure',lambda *args:fixed_configure(legacy,*args)):
                native.run(group,arm,ds,m)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('group',choices=['fresh_B1_a','fresh_B1_b','sequential_B1','sequential_fix'])
    run(p.parse_args().group)
