"""Freeze case-disjoint OpenI panels in native order and run paired crop geometry."""
import argparse
import json
from pathlib import Path
import re
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
from anatomy_crop import CXAS, crop_image
from mechanism import view_records

def records(path):
    return [json.loads(line) for line in path.read_text().splitlines()]

def study(row):
    return {match[1] for name in row['images']
            if (match := re.search(r'/(CXR\d+)_', name, re.I))}

def target(row):
    text = ' '.join([row['question'], *row['options'].values()]).lower()
    for pattern, region in [(r'hemidiaphragm|diaphragm', 'bilateral_hemidiaphragm'),
                            (r'basilar|basal|lung base|lower lobe', 'bilateral_lung_base'),
                            (r'apex|apical', 'bilateral_apex'), (r'mediastin', 'mediastinum'),
                            (r'cardiom|heart', 'heart'), (r'scoliosis|spine', 'spine')]:
        if re.search(pattern, text):
            return region
    return None

def freeze():
    manifest = json.loads((ROOT/'flash/generation/M5/chexbench/manifest.json').read_bytes())
    excluded = {x['question_id'] for p in [ROOT/'panel.jsonl',
                *(ROOT/'R56_M5_Evo/panels').glob('*.jsonl')] for x in records(p)}
    rows = manifest['inputs']
    used = set().union(*(study(r) for r in rows if r['question_id'] in excluded))
    panels = {}
    for key, size in [('crop12', 12), ('sequential32', 32)]:
        panel = []
        for r in rows:
            case = study(r)
            region = target(r)
            if ('_openi_' not in r['question_id'] or len(case) != 1 or case & used
                    or (key == 'crop12' and not region)):
                continue
            used.update(case)
            panel.append({'question_id': r['question_id'], 'study': next(iter(case)),
                          'dataset': 'chexbench', 'images': r['images'], 'region': region,
                          'laterality': bool(re.search(r'\bleft\b', str(r['options']), re.I)
                                             and re.search(r'\bright\b', str(r['options']), re.I))})
            if len(panel) == size:
                break
        assert len(panel) == size
        panels[key] = panel
    return manifest, panels

def run(arm, data, manifest, panel, device):
    views = view_records(ROOT, manifest)
    dest = HERE/'crop'/arm
    dest.mkdir(parents=True, exist_ok=True)
    model = CXAS(ROOT/'weights', device) if arm == 'C3' else None
    rows = []
    for item in panel:
        for i, name in enumerate(item['images'], 1):
            start = time.perf_counter()
            rec = crop_image(data/name, dest/item['question_id']/str(i), arm=arm, region=item['region'],
                             view_record=views[name], bilateral=item['laterality'], model=model)
            rows.append(dict(rec, question_id=item['question_id'], image_index=i,
                             seconds=time.perf_counter()-start))
    (dest/'calls.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    print(arm,[(r['crop_status'],r.get('fallback_reason')) for r in rows])

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--arm',choices=['C2','C3'])
    parser.add_argument('--data', type=Path)
    parser.add_argument('--device',default='cpu')
    args = parser.parse_args()
    manifest, panels = freeze()
    for key, rows in panels.items():
        path = HERE/(key+'.jsonl')
        value = ''.join(json.dumps(r)+'\n' for r in rows)
        if path.exists() and path.read_text() != value:
            raise ValueError('Frozen case membership changed')
        path.write_text(value)
    if args.arm:
        run(args.arm,args.data,manifest,panels['crop12'],args.device)
