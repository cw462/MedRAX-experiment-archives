import json
from collections import Counter
from audit import HERE,read,rows,dump

def paired(data):
    return dict(n=len(data),left=sum(a for a,b in data),right=sum(b for a,b in data),
                corrected=sum(not a and b for a,b in data),regressed=sum(a and not b for a,b in data))

def collect():
    au=rows(HERE/'audit/writes.jsonl'); inj=rows(HERE/'audit/injections.jsonl')
    pairs=rows(HERE/'audit/paired_scores.jsonl'); scored={r['question_id']:r for r in pairs}
    fixed=rows(HERE/'fixed_replay/graph_deltas.jsonl')
    shapes=Counter()
    for entry in rows(HERE/'audit/tool_trajectories.jsonl'):
        if entry['arm']!='B4':continue
        payload=entry['receipt']['observation']
        top=json.dumps([list(x) for x in payload] if isinstance(payload,list) else list(payload))
        shapes[entry['event']['tool'],entry['event']['analysis_status'],top]+=1
    dump(HERE/'audit/tool_fields.jsonl',[{'tool':tool,'payload_status':status,'container_keys':json.loads(keys),
            'calls':count} for (tool,status,keys),count in shapes.items()])
    identical=[]
    for r in au:
        ds,q=r['dataset'],r['question_id']
        p=[HERE/'source'/arm/ds for arm in ('B1','B4')]
        a,b=[read(d/'services/calls/R49-AGENT'/q/'1/request.json') for d in p]
        if a!=b:continue
        steps=[read(d/'steps'/f'{q}.json')[0]['response'] for d in p]
        identical.append({**scored[q],'first_response_changed':steps[0]!=steps[1]})
    dump(HERE/'audit/same_request_controls.jsonl',identical)
    old={r['question_id']:r for r in rows(HERE/'s2_B1_scores.jsonl')} if (HERE/'s2_B1_scores.jsonl').exists() else {}
    if old:
        if set(old)!=set(scored):raise ValueError('Unmatched B1 repeat questions')
        same=[{'question_id':q,'S2_correct':r['correct'],'repeat_correct':scored[q]['B1_correct']} for q,r in old.items()]
        dump(HERE/'audit/B1_online_repeat_scores.jsonl',same)
    metrics=dict(historical=paired([(r['B1_correct'],r['B4_correct']) for r in pairs]),
      historical_new_nodes=sum(len(r['created']) for r in au),historical_signals=dict(Counter(k for r in au for k in r['signals'])),
      field_mismatches=dict(Counter(f['tool'] for r in au for f in r['field_mismatches'])),
      injections={k:sum(r[k] for r in inj) for k in ('task_match','finding_match','view_match','sequence_changed','calls_or_args_changed')},
      injections_full_match=sum(r['task_match'] and r['finding_match'] and r['view_match'] for r in inj),
      injected_scores=paired([(r['B1_correct'],r['B4_correct']) for r in inj]),
      exact_first_request=paired([(r['B1_correct'],r['B4_correct']) for r in identical]),
      exact_first_responses_changed=sum(r['first_response_changed'] for r in identical),
      prior_online_B1=paired([(r['correct'],scored[q]['B1_correct']) for q,r in old.items()]) if old else None,
      fixed_candidates=dict(Counter(k for r in fixed for k in r['proposed'])),
      fixed_accepted=dict(Counter(k for r in fixed for k in r['accepted'])),
      model_reviewed=sum(1 for _ in (HERE/'model_reviews').glob('*.json')),
      graph_created=sum(len(r['created']) for r in fixed),graph_merged=sum(len(r['merged']) for r in fixed),
      graph_first_write=next((i for i,r in enumerate(fixed,1) if r['created']),None),
      graph_nodes=dict(Counter(n['kind'] for f in (HERE/'fixed_replay/graphs').glob('*/graph.json') for n in read(f)['nodes'])),
      graph_edges=sum(len(read(f)['edges']) for f in (HERE/'fixed_replay/graphs').glob('*/graph.json')),
      would_inject=sum(bool(r['replay_retrieval']['injected_ids']) for r in fixed),
      write_only_would_inject=sum(bool(r['write_only_retrieval']['injected_ids']) for r in fixed),crop={})
    for arm in ('C2','C3'):
        c=rows(HERE/'crop'/arm/'calls.jsonl')
        metrics['crop'][arm]={'n':len(c),'cropped':sum(r['crop_status']=='cropped' for r in c),
                              'fallback':dict(Counter(r['fallback_reason'] for r in c if r.get('fallback_reason'))),
                              'seconds':sum(r['seconds'] for r in c)}
    (HERE/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
    return metrics
if __name__=='__main__':print(json.dumps(collect(),indent=2))
